
window.onload = function () {
    calculate();
}
function start(){
    // hide id landing-page, display id calculator
    document.getElementById("landing-page").style.display = "none";
    document.getElementById("calculator").classList.remove('d-none');
    document.getElementById("calculator").classList.add('fade-in-fwd');



}
function calculate() {


    let balanceData = [
        [
            1,
            93367.26843772407
        ],
        [
            2,
            86148.26372411585
        ],
        [
            3,
            78291.16464422864
        ],
        [
            4,
            69739.56945898202
        ],
        [
            5,
            60432.091028484305
        ],
        [
            6,
            50301.91614793877
        ],
        [
            7,
            39276.32593285098
        ],
        [
            8,
            27276.173810650616
        ],
        [
            9,
            14215.317371519539
        ],
        [
            10,
            4.092726157978177e-12
        ]
    ];

    let interestData = [
        [
            1,
            8245.551102665388
        ],
        [
            2,
            15904.82905399853
        ],
        [
            3,
            22926.01263905264
        ],
        [
            4,
            29252.700118747332
        ],
        [
            5,
            34823.50435319097
        ],
        [
            6,
            39571.612137586766
        ],
        [
            7,
            43424.30458744031
        ],
        [
            8,
            46302.43513018127
        ],
        [
            9,
            48119.86135599151
        ],
        [
            10,
            48782.826649413306
        ]
    ];
    renderChart(balanceData, interestData);



}


// Render the balance over time chart
function renderChart(balanceData, interestData) {
    const options = {
        chart: {
            type: 'area', // Ensure it's set to 'area'
            height: 300,
            toolbar: {
                show: false // Disable export, zoom options, etc.
            },
            zoom: {
                enabled: false // Disable zooming in/out
            }
        },
        series: [{
            name: 'Annuity Balance',
            data: balanceData
        },
            {
                name: 'Interest Earned',
                data: interestData
            }],
        colors: ['#50465E', '#F87171'],

        xaxis: {
            title: {
                text: undefined
            }
        },
        yaxis: {
            title: {
                text: undefined
            },
            labels: {
                formatter: function (value) {
                    return '$ ' + value.toLocaleString('en-US', {
                        maximumFractionDigits: 0
                    });
                }
            }
        },
        tooltip: {
            y: {
                formatter: function (value) {
                    return '$' + value.toLocaleString('en-US', {
                        maximumFractionDigits: 0
                    });
                }
            },
            x: {
                formatter: function (value) {
                    return 'Year ' + value;
                }
            }
        },
        stroke: {
            curve: 'smooth',
            width: 2 // Adjust stroke width to make sure the line isn't too dominant
        },
        fill: {
            type: 'gradient', // Fill the area with a gradient
            gradient: {
                shadeIntensity: 1,
                opacityFrom: 0.4,
                opacityTo: 0.7,
                stops: [0, 90, 100]
            }
        },
        dataLabels: {
            enabled: false // Disable data labels on the chart itself
        },
        markers: {
            size: 5 // Add a slight marker to indicate data points
        },
        grid: {
            show: true,
            borderColor: '#e7e7e7'
        },
        theme: {
            fontFamily: 'Montserrat, sans-serif'
        }
    };

    const chart = new ApexCharts(document.querySelector("#lineChart"), options);
    chart.render();
}



function toComma(x) {
    return "$ " + x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

function toComma2(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}


function format(input) {
    var nStr = input.value + '';
    nStr = nStr.replace(/\,/g, "");
    x = nStr.split('.');
    x1 = x[0];
    x2 = x.length > 1 ? '.' + x[1] : '';
    var rgx = /(\d+)(\d{3})/;
    while (rgx.test(x1)) {
        x1 = x1.replace(rgx, '$1' + ',' + '$2');
    }
    input.value = x1 + x2;
}
